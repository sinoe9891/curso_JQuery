$(document).ready(function() {
    
});

$(function(){
    'use strict';
    console.log("listo!");
});
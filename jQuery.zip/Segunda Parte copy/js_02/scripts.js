
// Selectores
$(function(){
    'use strict';
    
    $('header');
    
    $('header .contenedor');
    
    $('.navegacion ').find('a');
    
    $('#navegacion');
    
    $('main article');
    
    $('main article:first')
    
     $('main article:first p ')
     
     $('main article:first p:first ')
    
     $('main article:first p:last ')
     
      $('main article:first p:last ').hide();
    
    
    $('nav ul li:first');
    
});